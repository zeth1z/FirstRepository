﻿using System;
using System.Threading;

/// <summary>
/// Пространство имён, содержащее программу для анимации слова.
/// </summary>
namespace WordAnimator
{
    /// <summary>
    /// Главный класс программы, реализующий анимацию ввода слова.
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Главная точка входа в программу.
        /// </summary>
        /// <param name="args">Аргументы командной строки (не используются).</param>
        static void Main(string[] args)
        {
            Console.Write("Write your word: ");
            string word = Console.ReadLine() ?? string.Empty;

            AnimateWord(word);
        }

        /// <summary>
        /// Анимирует процесс ввода слова, перебирая буквы алфавита и показывая постепенное совпадение.
        /// </summary>
        /// <param name="word">Слово, введённое пользователем, которое нужно написать.</param>
        /// <param name="delayMs">Время задержки в миллисекундах между шагами анимации для плавности.</param>
        static void AnimateWord(string word, int delayMs = 30)
        {
            string alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string res = "";
            string let = "";

            int i = 0, x = 0;

            while (true)
            {
                let += alphabet[i];

                if (word[x] == alphabet[i])
                {
                    i = 0;
                    res += let;
                    Console.WriteLine(res);
                    x++;
                }
                else
                {
                    i++;
                    Console.WriteLine(res + let);
                }

                if (i >= alphabet.Length)
                {
                    Console.WriteLine($"Error: symbol '{word[x]}' not found in alphabet.");
                    return;
                }

                if (word == res)
                    break;

                let = "";
                Thread.Sleep(delayMs);
            }
        }
    }
}